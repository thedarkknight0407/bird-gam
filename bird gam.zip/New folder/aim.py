import pygame as py
from display import *
from movement import *
py.init()

x =