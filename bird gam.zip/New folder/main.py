import pygame, display
pygame.init()

if __name__ == "__main__":
    display
    